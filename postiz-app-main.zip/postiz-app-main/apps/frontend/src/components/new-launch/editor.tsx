'use client';

import React, {
  FC,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  ClipboardEvent,
  forwardRef,
  useImperativeHandle,
} from 'react';
import clsx from 'clsx';
import { makeId } from '@gitroom/nestjs-libraries/services/make.is';
import EmojiPicker from 'emoji-picker-react';
import { Theme } from 'emoji-picker-react';
import { BoldText } from '@gitroom/frontend/components/new-launch/bold.text';
import { UText } from '@gitroom/frontend/components/new-launch/u.text';
import { SignatureBox } from '@gitroom/frontend/components/signature';
import { useT } from '@gitroom/react/translation/get.transation.service.client';
import {
  SelectedIntegrations,
  useLaunchStore,
} from '@gitroom/frontend/components/new-launch/store';
import { useShallow } from 'zustand/react/shallow';
import { AddPostButton } from '@gitroom/frontend/components/new-launch/add.post.button';
import { MultiMediaComponent } from '@gitroom/frontend/components/media/media.component';
import { UpDownArrow } from '@gitroom/frontend/components/launches/up.down.arrow';
import { deleteDialog } from '@gitroom/react/helpers/delete.dialog';
import { useExistingData } from '@gitroom/frontend/components/launches/helpers/use.existing.data';
import { useCopilotAction, useCopilotReadable } from '@copilotkit/react-core';
import { useDropzone } from 'react-dropzone';
import { useUppyUploader } from '@gitroom/frontend/components/media/new.uploader';
import { Dashboard } from '@uppy/react';
import Link from '@tiptap/extension-link';
import {
  useEditor,
  EditorContent,
  Extension,
  Node,
  mergeAttributes,
} from '@tiptap/react';
import Document from '@tiptap/extension-document';
import Bold from '@tiptap/extension-bold';
import Text from '@tiptap/extension-text';
import Paragraph from '@tiptap/extension-paragraph';
import Underline from '@tiptap/extension-underline';
import { stripHtmlValidation } from '@gitroom/helpers/utils/strip.html.validation';
import { History } from '@tiptap/extension-history';
import { BulletList, ListItem } from '@tiptap/extension-list';
import { Bullets } from '@gitroom/frontend/components/new-launch/bullets.component';
import Heading from '@tiptap/extension-heading';
import { Fragment, Slice } from '@tiptap/pm/model';
import { HeadingComponent } from '@gitroom/frontend/components/new-launch/heading.component';
import Mention from '@tiptap/extension-mention';
import { suggestion } from '@gitroom/frontend/components/new-launch/mention.component';
import { useFetch } from '@gitroom/helpers/utils/custom.fetch';
import { AComponent } from '@gitroom/frontend/components/new-launch/a.component';
import { Dropcursor, Placeholder, TrailingNode } from '@tiptap/extensions';
import { useToaster } from '@gitroom/react/toaster/toaster';
import { InformationComponent } from '@gitroom/frontend/components/launches/information.component';
import {
  LockIcon,
  ConnectionLineIcon,
  ResetIcon,
  TrashIcon,
  EmojiIcon,
  DelayIcon,
} from '@gitroom/frontend/components/ui/icons';
import { DelayComponent } from '@gitroom/frontend/components/new-launch/delay.component';

const MAX_UPLOAD_SIZE = 1024 * 1024 * 1024; // 1 GB

const InterceptBoldShortcut = Extension.create({
  name: 'preventBoldWithUnderline',

  addKeyboardShortcuts() {
    return {
      'Mod-b': () => {
        // For example, toggle bold while removing underline
        this?.editor?.commands?.unsetUnderline();
        return this?.editor?.commands?.toggleBold();
      },
    };
  },
});

const InterceptUnderlineShortcut = Extension.create({
  name: 'preventUnderlineWithUnderline',

  addKeyboardShortcuts() {
    return {
      'Mod-u': () => {
        // For example, toggle bold while removing underline
        this?.editor?.commands?.unsetBold();
        return this?.editor?.commands?.toggleUnderline();
      },
    };
  },
});

const EditorImage = Node.create({
  name: 'image',
  group: 'block',
  draggable: true,

  addAttributes() {
    return {
      src: { default: null },
      alt: { default: null },
    };
  },

  // same rule as the server sanitizer, any other source is dropped on save
  parseHTML() {
    return [{ tag: 'img[src^="https://"], img[src^="http://"]' }];
  },

  renderHTML({ HTMLAttributes }) {
    return ['img', HTMLAttributes];
  },
});

const insertImages = (
  editor: any,
  media: { path: string; alt?: string }[]
) => {
  if (!media.length) {
    return;
  }

  editor
    ?.chain()
    ?.focus()
    ?.insertContent(
      media.map((p) => ({
        type: 'image',
        attrs: { src: p.path, alt: p.alt },
      }))
    )
    ?.run();
};

export const EditorWrapper: FC<{
  totalPosts: number;
  value: string;
}> = () => {
  const t = useT();
  const {
    setGlobalValueText,
    setInternalValueText,
    addRemoveInternal,
    internal,
    global,
    current,
    addInternalValue,
    addGlobalValue,
    setInternalValueMedia,
    appendInternalValueMedia,
    appendGlobalValueMedia,
    setGlobalValueMedia,
    changeOrderGlobal,
    changeOrderInternal,
    isCreateSet,
    deleteGlobalValue,
    deleteInternalValue,
    setGlobalValue,
    setInternalValue,
    setInternalDelay,
    setGlobalDelay,
    internalFromAll,
    totalChars,
    postComment,
    dummy,
    editor,
    inlineImages,
    loadedState,
    setLoadedState,
    selectedIntegration,
    chars,
    comments,
  } = useLaunchStore(
    useShallow((state) => ({
      internal: state.internal.find((p) => p.integration.id === state.current),
      internalFromAll: state.integrations.find((p) => p.id === state.current),
      global: state.global,
      comments: state.comments,
      current: state.current,
      addRemoveInternal: state.addRemoveInternal,
      dummy: state.dummy,
      setInternalValueText: state.setInternalValueText,
      setGlobalValueText: state.setGlobalValueText,
      addInternalValue: state.addInternalValue,
      addGlobalValue: state.addGlobalValue,
      setGlobalValueMedia: state.setGlobalValueMedia,
      setInternalValueMedia: state.setInternalValueMedia,
      changeOrderGlobal: state.changeOrderGlobal,
      changeOrderInternal: state.changeOrderInternal,
      isCreateSet: state.isCreateSet,
      deleteGlobalValue: state.deleteGlobalValue,
      deleteInternalValue: state.deleteInternalValue,
      setGlobalValue: state.setGlobalValue,
      setInternalValue: state.setInternalValue,
      setGlobalDelay: state.setGlobalDelay,
      setInternalDelay: state.setInternalDelay,
      totalChars: state.totalChars,
      appendInternalValueMedia: state.appendInternalValueMedia,
      appendGlobalValueMedia: state.appendGlobalValueMedia,
      postComment: state.postComment,
      editor: state.editor,
      inlineImages: state.inlineImages,
      loadedState: state.loaded,
      setLoadedState: state.setLoaded,
      selectedIntegration: state.selectedIntegrations,
      chars: state.chars,
    }))
  );

  const existingData = useExistingData();
  const [loaded, setLoaded] = useState(true);

  useEffect(() => {
    if (loaded && loadedState) {
      return;
    }

    setLoadedState(true);
    setLoaded(true);
  }, [loaded, loadedState]);

  const canEdit = useMemo(() => {
    return current === 'global' || !!internal;
  }, [current, internal]);

  const items = useMemo(() => {
    if (internal) {
      return internal.integrationValue;
    }

    return global;
  }, [internal, global]);

  // phones show one toolbar, for the post that is being edited
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [focusIndex, setFocusIndex] = useState<number | null>(null);
  // without comments only the first post is shown
  const last = comments ? items.length - 1 : 0;
  const active = canEdit ? Math.min(activeIndex ?? last, last) : -1;

  const setValue = useCallback(
    (value: string[]) => {
      const newValue = value.map((p, index) => {
        return {
          id: makeId(10),
          delay: 0,
          ...(items?.[index]?.media
            ? { media: items[index].media }
            : { media: [] }),
          content: p,
        };
      });
      if (internal) {
        return setInternalValue(current, newValue);
      }

      return setGlobalValue(newValue);
    },
    [internal, items]
  );

  useCopilotReadable({
    description: 'Current content of posts',
    value: items.map((p) => p.content),
  });

  useCopilotAction({
    name: 'setPosts',
    description: 'a thread of posts',
    parameters: [
      {
        name: 'content',
        type: 'string[]',
        description: 'a thread of posts',
      },
    ],
    handler: async ({ content }) => {
      setValue(content);
    },
  });

  const changeValue = useCallback(
    (index: number) => (value: string) => {
      if (internal) {
        return setInternalValueText(current, index, value);
      }

      return setGlobalValueText(index, value);
    },
    [current, global, internal]
  );

  const changeImages = useCallback(
    (index: number) => (value: any[]) => {
      if (internal) {
        return setInternalValueMedia(current, index, value);
      }

      return setGlobalValueMedia(index, value);
    },
    [current, global, internal]
  );

  const appendImages = useCallback(
    (index: number) => (value: any[]) => {
      if (internal) {
        return appendInternalValueMedia(current, index, value);
      }

      return appendGlobalValueMedia(index, value);
    },
    [current, global, internal]
  );

  const changeOrder = useCallback(
    (index: number) => (direction: 'up' | 'down') => {
      setFocusIndex(null);
      if (internal) {
        changeOrderInternal(current, index, direction);
        return setLoaded(false);
      }

      changeOrderGlobal(index, direction);
      setLoaded(false);
    },
    [changeOrderInternal, changeOrderGlobal, current, global, internal]
  );

  const goBackToGlobal = useCallback(async () => {
    if (
      await deleteDialog(
        t(
          'are_you_sure_go_back_to_global_mode',
          'This action is irreversible. Are you sure you want to go back to global mode?'
        ),
        t('yes_go_back_to_global_mode', 'Yes, go back to global mode')
      )
    ) {
      setLoaded(false);
      addRemoveInternal(current);
    }
  }, [addRemoveInternal, current, t]);

  const addValue = useCallback(
    (index: number) => () => {
      setTimeout(() => {
        // scroll the the bottom
        document.querySelector('#social-content').scrollTo({
          top: document.querySelector('#social-content').scrollHeight,
        });
      }, 20);
      setActiveIndex(index + 1);
      if (window.matchMedia('(max-width: 1025px)').matches) {
        setFocusIndex(index + 1);
      }
      if (internal) {
        return addInternalValue(index, current, [
          {
            delay: 0,
            content: '',
            id: makeId(10),
            media: [],
          },
        ]);
      }

      return addGlobalValue(index, [
        {
          delay: 0,
          content: '',
          id: makeId(10),
          media: [],
        },
      ]);
    },
    [current, global, internal]
  );

  const deletePost = useCallback(
    (index: number) => async () => {
      if (
        !(await deleteDialog(
          t(
            'are_you_sure_delete_this_post',
            'Are you sure you want to delete this post?'
          ),
          t('yes_delete_it', 'Yes, delete it!')
        ))
      ) {
        return;
      }

      setActiveIndex((p) => (p !== null && p > index ? p - 1 : p));
      setFocusIndex(null);
      if (internal) {
        deleteInternalValue(current, index);
        return setLoaded(false);
      }

      deleteGlobalValue(index);
      setLoaded(false);
    },
    [current, global, internal, t]
  );

  const postButtons = (index: number) => (
    <div className="flex items-center mobile:flex-row-reverse mobile:gap-[8px]">
      <div className="flex-1 mobile:flex-none mobile:empty:hidden">
        {comments && (
          <AddPostButton
            num={index}
            onClick={addValue(index)}
            postComment={postComment}
          />
        )}
      </div>
      {!!internal && !existingData?.integration && (
        <div
          className="mt-[12px] flex gap-[20px] items-center cursor-pointer select-none mobile:mt-0 mobile:w-[40px] mobile:h-[40px] mobile:justify-center mobile:rounded-[8px] mobile:bg-btnSimple"
          onClick={goBackToGlobal}
        >
          <div className="flex gap-[6px] items-center mobile:hidden">
            <div className="w-[8px] h-[8px] rounded-full bg-[#FC69FF]" />
            <div className="text-[14px] font-[600]">
              {t('editing_a_specific_network', 'Editing a Specific Network')}
            </div>
          </div>
          <div className="flex gap-[6px] items-center">
            <div>
              <ResetIcon />
            </div>
            <div className="text-[13px] font-[600] mobile:hidden">
              {t('back_to_global', 'Back to global')}
            </div>
          </div>
        </div>
      )}
    </div>
  );

  if (!loaded || !loadedState) {
    return null;
  }

  return (
    <div
      className={clsx(
        // on phones the toolbar is fixed at the bottom, the posts leave room for it
        'relative flex-col gap-[20px] flex-1 min-w-0 mobile:flex mobile:gap-0 mobile:pb-[64px]',
        (items.length === 1 || !canEdit || !comments) && 'flex',
        ((!canEdit && !isCreateSet) || !comments) &&
          'bg-newSettings mobile:bg-transparent rounded-[12px]'
      )}
    >
      {isCreateSet && current !== 'global' && (
        <>
          <div className="text-center absolute w-full h-full left-0 top-0 items-center justify-center flex z-[101] flex-col gap-[16px]">
            <div>
              <div className="w-[54px] h-[54px] rounded-full absolute z-[101] flex justify-center items-center">
                <LockIcon />
              </div>
              <div className="w-[54px] h-[54px] rounded-full bg-newSettings opacity-80 mobile:bg-newBgColorInner mobile:opacity-100" />
            </div>
            <div className="text-[14px] font-[600] text-white mobile:text-textColor">
              {t(
                'cant_edit_networks_when_creating_set',
                "You can't edit networks when creating a set"
              )}
            </div>
          </div>
          <div className="absolute w-full h-full left-0 top-0 bg-newBackdrop opacity-60 mobile:bg-newSettings mobile:opacity-100 z-[100] rounded-[12px]" />
        </>
      )}
      {!canEdit && !isCreateSet && (
        <>
          <div
            onClick={() => {
              setLoaded(false);
              addRemoveInternal(current);
            }}
            className="text-center absolute w-full h-full p-[20px] left-0 top-0 items-center justify-center flex z-[101] flex-col gap-[16px]"
          >
            <div>
              <div className="w-[54px] h-[54px] rounded-full absolute z-[101] flex justify-center items-center">
                <LockIcon />
              </div>
              <div className="w-[54px] h-[54px] rounded-full bg-newSettings opacity-80 mobile:bg-newBgColorInner mobile:opacity-100" />
            </div>
            <div className="text-[14px] font-[600] text-white mobile:text-textColor">
              {t(
                'click_to_exit_global_editing',
                'Click this button to exit global editing and customize the post for this channel'
              )}
            </div>
            <div>
              <div className="text-white rounded-[8px] h-[44px] px-[20px] bg-[#D82D7E] cursor-pointer flex justify-center items-center">
                {t('edit_content', 'Edit content')}
              </div>
            </div>
          </div>
          <div className="absolute w-full h-full left-0 top-0 bg-newBackdrop opacity-60 mobile:bg-newSettings mobile:opacity-100 z-[100] rounded-[12px]" />
        </>
      )}
      {items.map((g, index) => (
        <div
          key={g.id}
          className={clsx(
            'relative flex flex-col gap-[20px] flex-1 bg-newSettings mobile:bg-transparent',
            index !== last && 'mobile:flex-none',
            index === 0 && 'rounded-t-[12px]',
            (index === items.length - 1 || !comments) && 'rounded-b-[12px]',
            !canEdit && !isCreateSet && 'blur-s',
            ((!canEdit && index > 0) || (!comments && index > 0)) && 'hidden'
          )}
        >
          <div className="flex gap-[5px] mobile:gap-[16px] flex-1 w-full min-w-0">
            <div className="flex-1 flex w-full min-w-0">
              {index > 0 && (
                <div className="flex justify-center pl-[12px] text-newSep mobile:hidden">
                  <ConnectionLineIcon />
                </div>
              )}
              <Editor
                flat={true}
                active={active === index}
                autoFocus={focusIndex === index}
                onActive={() => {
                  setActiveIndex(index);
                  setFocusIndex(null);
                }}
                comments={comments}
                editorType={editor}
                inlineImages={editor === 'html' && inlineImages && index === 0}
                allValues={items}
                onChange={changeValue(index)}
                key={index}
                num={index}
                totalPosts={global.length}
                value={g.content}
                pictures={g.media}
                setImages={changeImages(index)}
                autoComplete={canEdit}
                validateChars={true}
                identifier={internalFromAll?.identifier || 'global'}
                totalChars={totalChars}
                appendImages={appendImages(index)}
                dummy={dummy}
                selectedIntegration={selectedIntegration}
                chars={chars}
                childButton={
                  (canEdit && items.length - 1 === index) || !comments
                    ? postButtons(index)
                    : null
                }
                toolBarEnd={active === index ? postButtons(index) : undefined}
              />
            </div>
            {comments && (
              <div
                className={clsx(
                  // on phones the icons sit in the corner, next to the first line
                  'flex flex-col items-center gap-[10px] pe-[12px] mobile:absolute mobile:top-[24px] mobile:end-0 mobile:z-[100] mobile:flex-row-reverse mobile:gap-[12px] mobile:pe-0',
                  // the first post can't be deleted on phones, like the app
                  index === 0 && 'mobile:hidden'
                )}
              >
                <div className="mobile:hidden">
                  <UpDownArrow
                    isUp={index !== 0}
                    isDown={index !== items.length - 1}
                    onChange={changeOrder(index)}
                  />
                </div>
                {items.length > 1 && (
                  <TrashIcon
                    onClick={deletePost(index)}
                    data-tooltip-id="tooltip"
                    data-tooltip-content={t(
                      'delete_post_tooltip',
                      'Delete Post'
                    )}
                    className="cursor-pointer text-[#FF3F3F]"
                  />
                )}
                {index > 0 && (
                  <DelayComponent currentIndex={index} currentDelay={g.delay} />
                )}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export const Editor: FC<{
  flat?: boolean;
  // phones: the post that is being edited shows the toolbar
  active?: boolean;
  autoFocus?: boolean;
  onActive?: () => void;
  toolBarEnd?: React.ReactNode;
  editorType?: 'none' | 'normal' | 'markdown' | 'html';
  inlineImages?: boolean;
  totalPosts: number;
  value: string;
  num?: number;
  pictures?: any[];
  allValues?: any[];
  onChange: (value: string) => void;
  setImages?: (value: any[]) => void;
  appendImages?: (value: any[]) => void;
  autoComplete?: boolean;
  validateChars?: boolean;
  comments: boolean | 'no-media';
  identifier?: string;
  totalChars?: number;
  selectedIntegration: SelectedIntegrations[];
  dummy: boolean;
  chars: Record<string, number>;
  childButton?: React.ReactNode;
}> = (props) => {
  const {
    flat,
    active,
    autoFocus,
    onActive,
    toolBarEnd,
    editorType = 'normal',
    inlineImages = false,
    allValues,
    pictures,
    setImages,
    num,
    identifier,
    appendImages,
    dummy,
    chars,
    childButton,
    comments,
  } = props;
  const [id] = useState(makeId(10));
  const [emojiPickerOpen, setEmojiPickerOpen] = useState(false);
  const t = useT();
  const toaster = useToaster();
  const editorRef = useRef<undefined | { editor: any }>(undefined);
  const [loading, setLoading] = useState(false);
  // the uploader is created once, so it reads the latest value from here
  const inlineImagesRef = useRef(inlineImages);
  inlineImagesRef.current = inlineImages;

  const uppy = useUppyUploader({
    onUploadSuccess: (result: any) => {
      const editor = editorRef?.current?.editor;
      if (inlineImagesRef.current && editor) {
        insertImages(editor, result);
        return;
      }

      appendImages(result);
    },
    allowedFileTypes: 'image/*,video/mp4',
    onStart: () => {},
    onEnd: () => setLoading(false),
  });

  // inline images go into the content, which only holds pictures
  const filterFiles = useCallback(
    (files: File[]) => {
      if (!inlineImages) {
        return files;
      }

      const images = files.filter((file) => file.type.startsWith('image/'));
      if (images.length < files.length) {
        toaster.show(
          t(
            'only_images_can_be_added_to_the_content',
            'Only images can be added to the content'
          ),
          'warning'
        );
      }

      return images;
    },
    [inlineImages, toaster, t]
  );

  const onDrop = useCallback(
    (droppedFiles: File[]) => {
      const acceptedFiles = filterFiles(droppedFiles);
      if (!acceptedFiles.length) {
        return;
      }

      const totalSize = acceptedFiles.reduce((acc, file) => acc + file.size, 0);

      if (totalSize > MAX_UPLOAD_SIZE) {
        toaster.show(
          t(
            'upload_size_limit_exceeded',
            'Upload size limit exceeded. Maximum 1 GB per upload session.'
          ),
          'warning'
        );
        return;
      }

      setLoading(true);

      for (const file of acceptedFiles) {
        uppy.addFile(file);
      }
    },
    [uppy, toaster, t, filterFiles]
  );

  const paste = useCallback(
    (event: ClipboardEvent | File[], slice?: Slice) => {
      if (num > 0 && comments === 'no-media') {
        return false;
      }
      // @ts-ignore
      const clipboardItems = event.clipboardData?.items;
      if (!clipboardItems) {
        return false;
      }

      const clipboardFiles: File[] = [];
      // @ts-ignore
      for (const item of clipboardItems) {
        if (item.kind === 'file') {
          const file = item.getAsFile();
          if (file) {
            clipboardFiles.push(file);
          }
        }
      }

      // a copied picture also comes as html linking to the site it was copied
      // from, so the file wins unless the html has text of its own
      // @ts-ignore
      const html = event.clipboardData.getData('text/html');
      const uploadInline =
        !!clipboardFiles.length &&
        (!html || !slice?.content.textBetween(0, slice.content.size).trim());
      if (inlineImages && !uploadInline) {
        return false;
      }

      const files = filterFiles(clipboardFiles);
      const totalSize = files.reduce((acc, file) => acc + file.size, 0);

      if (totalSize > MAX_UPLOAD_SIZE) {
        toaster.show(
          t(
            'upload_size_limit_exceeded',
            'Upload size limit exceeded. Maximum 1 GB per upload session.'
          ),
          'warning'
        );
        return false;
      }

      if (files.length > 0) {
        setLoading(true);
      }

      for (const file of files) {
        uppy.addFile(file);
      }

      // the uploaded pictures replace the pasted html
      return inlineImages;
    },
    [uppy, num, comments, toaster, t, inlineImages, filterFiles]
  );

  // a drag that starts on the page (like moving a picture inside the editor)
  // is not an upload, but Chrome reports a dragged <img> as "Files"
  const [internalDrag, setInternalDrag] = useState(false);
  useEffect(() => {
    if (!inlineImages) {
      return;
    }

    const dragStart = (event: DragEvent) => {
      if (!event.defaultPrevented) {
        setInternalDrag(true);
      }
    };
    const dragEnd = () => setInternalDrag(false);

    window.addEventListener('dragstart', dragStart);
    window.addEventListener('dragend', dragEnd);
    window.addEventListener('drop', dragEnd);
    return () => {
      window.removeEventListener('dragstart', dragStart);
      window.removeEventListener('dragend', dragEnd);
      window.removeEventListener('drop', dragEnd);
      setInternalDrag(false);
    };
  }, [inlineImages]);

  const { getRootProps, isDragActive } = useDropzone({
    onDrop: (files, _, event) => {
      if (loading) {
        toaster.show(
          'Upload current in progress, please wait and then try again.',
          'warning'
        );
        return;
      }

      if (inlineImages) {
        // uploads land at the cursor, move it to where the files were dropped
        const editor = editorRef?.current?.editor;
        const { clientX, clientY } = event as DragEvent;
        const position = editor?.view?.posAtCoords({
          left: clientX,
          top: clientY,
        });
        if (position) {
          editor.commands.focus(position.pos);
        }
      }

      onDrop(files);
    },
    noDrag: internalDrag || (num > 0 && comments === 'no-media'),
  });

  const valueWithoutHtml = useMemo(() => {
    return stripHtmlValidation('normal', props.value || '', true);
  }, [props.value]);

  const addText = useCallback(
    (emoji: string) => {
      editorRef?.current?.editor?.commands?.insertContent(emoji);
      editorRef?.current?.editor?.commands?.focus();
    },
    [props.value, id]
  );

  // the extensions are fixed once the editor is created, rebuild it when they change
  const editorKey = `${editorType}-${inlineImages}`;
  const [loadedEditor, setLoadedEditor] = useState(editorKey);
  const [showEditor, setShowEditor] = useState(true);
  useEffect(() => {
    if (editorKey === loadedEditor) {
      return;
    }
    setLoadedEditor(editorKey);
    setShowEditor(false);
  }, [editorKey]);

  useEffect(() => {
    if (showEditor) {
      return;
    }
    setTimeout(() => {
      setShowEditor(true);
    }, 20);
  }, [showEditor]);

  // phones: a tap on an empty part of the post starts typing in it
  const focusOnEmpty = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const control = (e.target as HTMLElement).closest(
      '.ProseMirror, .cursor-pointer, .group, .post-toolbar, button, input, aside, img, video'
    );
    if (
      !window.matchMedia('(max-width: 1025px)').matches ||
      editorRef?.current?.editor?.isFocused ||
      (control && e.currentTarget.contains(control))
    ) {
      return;
    }
    editorRef?.current?.editor?.commands?.focus('end');
  }, []);

  // phones: the toolbar of the edited post sits right above the on-screen keyboard
  const [keyboard, setKeyboard] = useState(0);
  useEffect(() => {
    const viewport = window.visualViewport;
    if (!flat || !active || !viewport) {
      return;
    }

    const update = () => {
      setKeyboard(
        Math.max(0, window.innerHeight - viewport.height - viewport.offsetTop)
      );
    };
    update();
    viewport.addEventListener('resize', update);
    viewport.addEventListener('scroll', update);
    return () => {
      viewport.removeEventListener('resize', update);
      viewport.removeEventListener('scroll', update);
    };
  }, [flat, active]);

  if (!showEditor) {
    return null;
  }

  return (
    <div
      className={clsx(
        'flex flex-col gap-[20px] flex-1 min-w-0',
        flat && 'flat-editor'
      )}
      onClick={flat ? focusOnEmpty : undefined}
    >
      <div
        className={clsx(
          'relative flex-1 px-[12px] pt-[12px] pb-[12px] flex flex-col',
          num > 0 && '!rounded-bs-[0]',
          // the composer has no cards on phones, the text lines up with the page
          flat && 'mobile:px-0 mobile:pb-0',
          // the space above a comment belongs to it, so a tap there types in it
          flat && (num ? 'mobile:pt-[24px]' : 'mobile:pt-0')
        )}
        id={id}
      >
        <div className="relative cursor-text flex flex-1 flex-col">
          <div {...getRootProps()} className="flex flex-1 flex-col">
            <div
              className={clsx(
                'absolute left-0 top-0 w-full h-full bg-black/70 z-[300] transition-all items-center justify-center flex text-white text-sm',
                !isDragActive ? 'pointer-events-none opacity-0' : 'opacity-100'
              )}
            >
              {t('drop_files_here_to_upload', 'Drop your files here to upload')}
            </div>
            <div
              onFocus={onActive}
              className={clsx(
                'px-[10px] pt-[10px] bg-newBgColorInner rounded-t-[6px] relative z-[99]',
                flat && 'mobile:px-0 mobile:pt-0',
                flat && !active && 'mobile:text-textItemBlur',
                // room for the delay and delete icons of a comment
                flat && !!num && 'mobile:pe-[68px]'
              )}
            >
              <OnlyEditor
                value={props.value}
                editorType={editorType}
                inlineImages={inlineImages}
                onChange={props.onChange}
                paste={paste}
                autoFocus={autoFocus}
                ref={editorRef}
              />
            </div>
            <div
              className={clsx(
                'bg-newBgColorInner flex-1',
                flat && 'mobile:hidden'
              )}
              onClick={() => {
                if (editorRef?.current?.editor?.isFocused) {
                  return;
                }
                editorRef?.current?.editor?.commands?.focus('end');
              }}
            />
            <div className="w-full pointer-events-none">
              <div className="w-full h-[46px] overflow-hidden absolute left-0 bg-newBgColorInner uppyChange mobile:isolate">
                <Dashboard
                  height={46}
                  uppy={uppy}
                  id={`prog-${num}`}
                  showProgressDetails={true}
                  hideUploadButton={true}
                  hideRetryButton={true}
                  hidePauseResumeButton={true}
                  hideCancelButton={true}
                  hideProgressAfterFinish={true}
                />
              </div>
            </div>
            <div
              className={clsx(
                'w-full h-[46px] bg-newBgColorInner cursor-text',
                // the upload progress shows over this space
                flat && !loading && 'mobile:hidden'
              )}
              onClick={() => {
                if (editorRef?.current?.editor?.isFocused) {
                  return;
                }
                editorRef?.current?.editor?.commands?.focus('end');
              }}
            />
            <div className={clsx('flex flex-col', flat && 'mobile:pt-[16px]')}>
              <div className="flex bg-newBgColorInner rounded-b-[6px] cursor-default">
                {setImages && (
                  <MultiMediaComponent
                    mediaNotAvailable={num > 0 && comments === 'no-media'}
                    allData={allValues}
                    text={valueWithoutHtml}
                    label={t('attachments', 'Attachments')}
                    description=""
                    value={props.pictures}
                    dummy={dummy}
                    name="image"
                    insertInContent={
                      inlineImages
                        ? (media) =>
                            insertImages(editorRef?.current?.editor, media)
                        : undefined
                    }
                    information={
                      <InformationComponent
                        isPicture={pictures?.length > 0}
                        chars={chars}
                        totalChars={valueWithoutHtml.length}
                        totalAllowedChars={props.totalChars}
                        text={valueWithoutHtml}
                      />
                    }
                    toolBar={
                      <div className="flex gap-[5px] mobile:gap-[4px]">
                        <SignatureBox editor={editorRef?.current?.editor} />
                        {editorType !== 'none' && (
                          <>
                            <UText
                              editor={editorRef?.current?.editor}
                              currentValue={props.value!}
                            />
                            <BoldText
                              editor={editorRef?.current?.editor}
                              currentValue={props.value!}
                            />
                          </>
                        )}
                        {(editorType === 'markdown' || editorType === 'html') &&
                          identifier !== 'telegram' && (
                            <>
                              <AComponent
                                editor={editorRef?.current?.editor}
                                currentValue={props.value!}
                              />
                              <Bullets
                                editor={editorRef?.current?.editor}
                                currentValue={props.value!}
                              />
                              <HeadingComponent
                                editor={editorRef?.current?.editor}
                                currentValue={props.value!}
                              />
                            </>
                          )}
                        <div
                          data-tooltip-id="tooltip"
                          data-tooltip-content={t(
                            'insert_emoji',
                            'Insert Emoji'
                          )}
                          className="select-none cursor-pointer rounded-[6px] mobile:rounded-[8px] w-[30px] h-[30px] mobile:w-[40px] mobile:h-[40px] bg-newColColor mobile:bg-newSettings flex justify-center items-center"
                          onClick={() => setEmojiPickerOpen(!emojiPickerOpen)}
                        >
                          <EmojiIcon className="mobile:w-[20px] mobile:h-[20px]" />
                        </div>
                        <div className="relative">
                          {emojiPickerOpen && (
                            <div
                              className="hidden mobile:block fixed inset-0 z-[499]"
                              onClick={(e) => {
                                e.stopPropagation();
                                setEmojiPickerOpen(false);
                              }}
                            />
                          )}
                          <div
                            className={clsx(
                              'absolute z-[500] -start-[50px]',
                              num === 0 && allValues?.length > 1
                                ? 'top-[35px]'
                                : 'bottom-[35px]',
                              // the toolbar scrolls on phones and would cut the picker
                              'mobile:fixed mobile:inset-x-0 mobile:top-auto mobile:bottom-[72px] mobile:flex mobile:justify-center mobile:pointer-events-none mobile:child:pointer-events-auto'
                            )}
                          >
                            <EmojiPicker
                              height={400}
                              theme={
                                (localStorage.getItem('mode') as Theme) ||
                                Theme.DARK
                              }
                              onEmojiClick={(e) => {
                                addText(e.emoji);
                                setEmojiPickerOpen(false);
                              }}
                              open={emojiPickerOpen}
                            />
                          </div>
                        </div>
                      </div>
                    }
                    toolsClassName={
                      flat
                        ? active
                          ? clsx(
                              'post-toolbar mobile:fixed mobile:bottom-0 mobile:inset-x-0 mobile:items-center mobile:px-[16px] mobile:py-[12px] mobile:bg-newBgColorInner',
                              // the picker opens from the bar and has to cover the top bar
                              emojiPickerOpen ? 'mobile:z-[500]' : 'mobile:z-[440]'
                            )
                          : 'mobile:hidden'
                        : undefined
                    }
                    toolsStyle={
                      flat && active && keyboard ? { bottom: keyboard } : undefined
                    }
                    toolBarEnd={
                      flat && active ? (
                        <div className="hidden mobile:flex">{toolBarEnd}</div>
                      ) : undefined
                    }
                    onChange={(value) => {
                      setImages(value.target.value);
                    }}
                    onOpen={() => {}}
                    onClose={() => {}}
                  />
                )}
              </div>
              <div className="mobile:hidden">{childButton}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const OnlyEditor = forwardRef<
  any,
  {
    editorType: 'none' | 'normal' | 'markdown' | 'html';
    inlineImages?: boolean;
    value: string;
    onChange: (value: string) => void;
    paste?: (event: ClipboardEvent | File[], slice?: Slice) => boolean;
    autoFocus?: boolean;
  }
>(({ editorType, inlineImages, value, onChange, paste, autoFocus }, ref) => {
  const t = useT();
  const fetch = useFetch();

  const { internal } = useLaunchStore(
    useShallow((state) => ({
      internal: state.internal.find((p) => p.integration.id === state.current),
    }))
  );

  const loadList = useCallback(
    async (query: string) => {
      if (query.length < 2) {
        return [];
      }

      if (!internal?.integration.id) {
        return [];
      }

      try {
        const load = await fetch('/integrations/mentions', {
          method: 'POST',
          body: JSON.stringify({
            name: 'mention',
            id: internal.integration.id,
            data: { query },
          }),
        });

        const result = await load.json();
        return result;
      } catch (error) {
        console.error('Error loading mentions:', error);
        return [];
      }
    },
    [internal, fetch]
  );

  const editor = useEditor({
    extensions: [
      Document,
      Paragraph.configure({
        HTMLAttributes: {
          dir: 'auto',
        },
      }),
      Text,
      Underline,
      Bold,
      InterceptBoldShortcut,
      InterceptUnderlineShortcut,
      BulletList,
      ListItem,
      Placeholder.configure({
        placeholder: t('write_something', 'Write something …'),
        emptyEditorClass: 'is-editor-empty',
      }),
      ...(editorType === 'html' || editorType === 'markdown'
        ? [
            Link.configure({
              openOnClick: false,
              autolink: true,
              defaultProtocol: 'https',
              protocols: ['http', 'https'],
              isAllowedUri: (url, ctx) => {
                try {
                  // prevent transforming plain emails like foo@bar.com into links
                  const trimmed = String(url).trim();
                  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                  if (emailPattern.test(trimmed)) {
                    return false;
                  }

                  // construct URL
                  const parsedUrl = url.includes(':')
                    ? new URL(url)
                    : new URL(`${ctx.defaultProtocol}://${url}`);

                  // use default validation
                  if (!ctx.defaultValidate(parsedUrl.href)) {
                    return false;
                  }

                  // disallowed protocols
                  const disallowedProtocols = ['ftp', 'file', 'mailto'];
                  const protocol = parsedUrl.protocol.replace(':', '');

                  if (disallowedProtocols.includes(protocol)) {
                    return false;
                  }

                  // only allow protocols specified in ctx.protocols
                  const allowedProtocols = ctx.protocols.map((p) =>
                    typeof p === 'string' ? p : p.scheme
                  );

                  if (!allowedProtocols.includes(protocol)) {
                    return false;
                  }

                  // all checks have passed
                  return true;
                } catch {
                  return false;
                }
              },
              shouldAutoLink: (url) => {
                try {
                  // prevent auto-linking of plain emails like foo@bar.com
                  const trimmed = String(url).trim();
                  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                  if (emailPattern.test(trimmed)) {
                    return false;
                  }

                  // construct URL
                  const parsedUrl = url.includes(':')
                    ? new URL(url)
                    : new URL(`https://${url}`);

                  // only auto-link if the domain is not in the disallowed list
                  const disallowedDomains = [
                    'example-no-autolink.com',
                    'another-no-autolink.com',
                  ];
                  const domain = parsedUrl.hostname;

                  return !disallowedDomains.includes(domain);
                } catch {
                  return false;
                }
              },
            }),
          ]
        : []),
      ...(internal?.integration?.id
        ? [
            Mention.configure({
              HTMLAttributes: {
                class: 'mention',
              },
              renderHTML({ options, node }) {
                return [
                  'span',
                  mergeAttributes(options.HTMLAttributes, {
                    'data-mention-id': node.attrs.id || '',
                    'data-mention-label': node.attrs.label || '',
                  }),
                  `@${node.attrs.label}`,
                ];
              },
              suggestion: suggestion(loadList),
            }),
          ]
        : []),
      ...(editorType === 'html' || editorType === 'markdown'
        ? [
            Heading.configure({
              levels: [1, 2, 3],
              HTMLAttributes: {
                dir: 'auto',
              },
            }),
          ]
        : []),
      ...(inlineImages
        ? [
            EditorImage,
            Dropcursor.configure({
              color: 'var(--new-btn-primary)',
              width: 2,
            }),
            // a picture can't hold the cursor, keep a paragraph after a
            // trailing one so clicking below the content doesn't select it
            TrailingNode.configure({
              node: 'paragraph',
              notAfter: ['heading', 'bulletList'],
            }),
          ]
        : []),
      History.configure({
        depth: 100, // default is 100
        newGroupDelay: 100, // default is 500ms
      }),
    ],
    content: value || '',
    autofocus: autoFocus ? 'end' : false,
    shouldRerenderOnTransaction: true,
    immediatelyRender: false,
    editorProps: {
      handlePaste: (view, event, slice) => !!paste?.(event as any, slice),
      // the default parser merges consecutive newlines, which drops the
      // blank lines of pasted plain text; keep each one as an empty paragraph
      clipboardTextParser: (text, $context, _plain, view) => {
        const { schema } = view.state;
        const marks = $context.marks();
        return Slice.maxOpen(
          Fragment.from(
            text
              .split(/\r\n?|\n/)
              .map((line) =>
                schema.nodes.paragraph.create(
                  null,
                  line ? schema.text(line, marks) : undefined
                )
              )
          )
        );
      },
    },
    onUpdate: (innerProps) => {
      onChange?.(innerProps.editor.getHTML());
    },
  });

  useImperativeHandle(ref, () => ({
    editor,
  }));

  return <EditorContent editor={editor} />;
});
